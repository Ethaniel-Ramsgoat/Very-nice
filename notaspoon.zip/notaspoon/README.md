# Fork Bomb
fork bombs in lots of different languages. Please fork (ba dum crash) and contribute.

Current languages:

 - Ada
 - Assembly
 - AWK
 - Bash
 - Batch
 - Brainfuck
 - C
 - C++
 - C#
 - C# (.Net Core) under Linux
 - Erlang
 - FASM
 - Go
 - Haskell
 - HTML
 - Java
 - JavaScript
 - Lisp
 - Lua
 - Microsoft Access
 - PHP
 - Perl
 - Python
 - R
 - Ruby
 - Rust
 - Scheme
 - Shell
 - Visual Basic
