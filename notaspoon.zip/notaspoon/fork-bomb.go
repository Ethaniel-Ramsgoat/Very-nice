package main

func main() {
	for {
		go main()
	}
}
