library(multicore)
 
while (TRUE) fork()
