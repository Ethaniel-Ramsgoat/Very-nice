#!/bin/bash
./$0|./$0&     # $0 is the name of the shell script itself
